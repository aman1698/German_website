<!DOCTYPE html>
<html lang="en-US">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
  <meta name="description" content="Organize anything, together. Trello is a collaboration tool that organizes your projects into boards. In one glance, know what's being worked on, who's working on what, and where something is in a process.">
  <meta name="viewport" content="maximum-scale=1.0,width=device-width,initial-scale=1.0,user-scalable=0">
  <meta name="apple-itunes-app" content="app-id=461504587">
  <meta name="slack-app-id" content="A074YH40Z">
  <meta name="robots" content="noarchive">
  <meta name="referrer" content="origin-when-cross-origin">
  <title>Trello</title>
  <script>
  //Support for IE11 ends 2019-03-31
  (function(a){/Trident\/7/.test(navigator.userAgent)&&(a.location="/support/ie11?returnUrl="+encodeURIComponent(a.location.href))})(window);
  </script>
  <script>var _failed=function(a){a=a.src||a.href;var b=function(a){if(a=/^https?:\/\/[^\/]+/.exec(a))return a[0]},b=b(a)||b(location.href)||"unknown";ga('send','event','Load Failure',b,a)};</script>
  <link rel="stylesheet" href="https://a.trellocdn.com/prgb/dist/core.8657286f9f3037871aad.css" onerror="_failed(this)">
  <script type="text/javascript">
    window.trelloVersion = 'build-4506';
    window.locale = 'en-US';
  </script>
  <script>
    !function(e){function a(a){for(var t,c,i=a[0],d=a[1],f=a[2],l=0,u=[];l<i.length;l++)c=i[l],Object.prototype.hasOwnProperty.call(n,c)&&n[c]&&u.push(n[c][0]),n[c]=0;for(t in d)Object.prototype.hasOwnProperty.call(d,t)&&(e[t]=d[t]);for(b&&b(a);u.length;)u.shift()();return o.push.apply(o,f||[]),r()}function r(){for(var e,a=0;a<o.length;a++){for(var r=o[a],t=!0,i=1;i<r.length;i++){var d=r[i];0!==n[d]&&(t=!1)}t&&(o.splice(a--,1),e=c(c.s=r[0]))}return e}var t={},n={0:0},o=[];function c(a){if(t[a])return t[a].exports;var r=t[a]={i:a,l:!1,exports:{}};return e[a].call(r.exports,r,r.exports,c),r.l=!0,r.exports}c.e=function(e){var a=[],r=n[e];if(0!==r)if(r)a.push(r[2]);else{var t=new Promise(function(a,t){r=n[e]=[a,t]});a.push(r[2]=t);var o,i=document.createElement("script");i.charset="utf-8",i.timeout=120,c.nc&&i.setAttribute("nonce",c.nc),i.src=function(e){return c.p+""+({2:"@ak-switcher-chunk-atlassian-switcher",3:"@ak-switcher-chunk-confluence-switcher",4:"@ak-switcher-chunk-generic-switcher",5:"@ak-switcher-chunk-jira-switcher",6:"@ak-switcher-chunk-trello-switcher",7:"aa-migration-wizard",8:"actionable-task-view",10:"app-management",11:"butler-view",12:"calendar-controller-view",13:"closed-boards-overlay",16:"create-board-overlay",17:"create-menu-popover",18:"download-support-debug-data",19:"email-hygiene-wizard",20:"emoji-mart-data-twitter",21:"enterprise-admin-dashboard-view",22:"enterprise-menu-popover",23:"free-team-limit-banners",24:"gamma-create-team-overlay",25:"gamma-cross-flow-overlay",26:"google-marker-cluster-plus",28:"info-menu-popover",53:"map-view",54:"member-account-view",55:"member-activity-view",56:"member-billing-view",57:"member-billing-view-legacy",58:"member-cards-view",59:"member-profile-view",60:"notifications-menu-popover",61:"organization-account-view",62:"organization-billing-view",63:"organization-billing-view-legacy",64:"organization-boards-view",65:"organization-export-view",66:"organization-members-view",67:"organization-power-ups-view",69:"pikaday",70:"power-up-directory",72:"search-results-popover",73:"shortcuts",76:"taco-announcements",77:"team-report-container",78:"team-report-download",79:"templates-container"}[e]||e)+"."+{2:"68ead25d2e21dee3a15e",3:"35bd1e32541b15bc2f34",4:"b1eab113b7d07a0057fd",5:"3c74b1d6d7393953e1cd",6:"af62b8c78fab7baef0c7",7:"4fc3c5bf28a0b65d469d",8:"1ab12d9ff3d8fad2cf48",10:"764bf4967f313f5cde55",11:"ca91f6d367d9beb84941",12:"6218e324cc1dbada6764",13:"29da1c669e0cb03c2c7a",16:"271cf4b84d6f19324f29",17:"761c0d7235319e7b44d9",18:"a1493b422886f100cae8",19:"7fc0f3a5c9032acc6b6c",20:"605576dcd0b9be4cf69c",21:"223a7356764465e80eac",22:"3339cc7182e51222cd01",23:"086f1602fc7b712ade8d",24:"ff7270b98a9fb3a56fc7",25:"b1b6163989215934a2da",26:"e6e40726c3786df7e297",28:"3cf556a5503b9c46276f",53:"3b0190e40a95f738bc4d",54:"3311026e71bfd57188e1",55:"f69e281f5986885c0814",56:"16dfd50daacd1ed603df",57:"fbf2fb22c2e533c5b96d",58:"77ae2f27fd7a65cfc9b0",59:"80b138d06b66983fcbeb",60:"146ac367bf1b57c2a0dd",61:"a27849a5a079e88e067d",62:"da94a4015c9b9ae7e7c6",63:"c0fb743a68e566fedb41",64:"f51a2b6c36d1c130930b",65:"9af8b64e0848168bdd21",66:"8b8b64f97fc98850647d",67:"029865743f985e704ad4",69:"3299eef742ca6f7e558d",70:"846378fc2526f419e86f",72:"58174606009d040a8de9",73:"760af59dfb8ed064439d",76:"1c26daca084bbf2fe032",77:"9e1ce537532bccab2d17",78:"58cad572d9a4a60dba5b",79:"24b50ac59aa4a0d1b110"}[e]+".js"}(e);var d=new Error;o=function(a){i.onerror=i.onload=null,clearTimeout(f);var r=n[e];if(0!==r){if(r){var t=a&&("load"===a.type?"missing":a.type),o=a&&a.target&&a.target.src;d.message="Loading chunk "+e+" failed.\n("+t+": "+o+")",d.name="ChunkLoadError",d.type=t,d.request=o,r[1](d)}n[e]=void 0}};var f=setTimeout(function(){o({type:"timeout",target:i})},12e4);i.onerror=i.onload=o,document.head.appendChild(i)}return Promise.all(a)},c.m=e,c.c=t,c.d=function(e,a,r){c.o(e,a)||Object.defineProperty(e,a,{enumerable:!0,get:r})},c.r=function(e){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},c.t=function(e,a){if(1&a&&(e=c(e)),8&a)return e;if(4&a&&"object"==typeof e&&e&&e.__esModule)return e;var r=Object.create(null);if(c.r(r),Object.defineProperty(r,"default",{enumerable:!0,value:e}),2&a&&"string"!=typeof e)for(var t in e)c.d(r,t,function(a){return e[a]}.bind(null,t));return r},c.n=function(e){var a=e&&e.__esModule?function(){return e.default}:function(){return e};return c.d(a,"a",a),a},c.o=function(e,a){return Object.prototype.hasOwnProperty.call(e,a)},c.p="https://a.trellocdn.com/prgb/dist/",c.oe=function(e){throw console.error(e),e};var i=window.webpackJsonp=window.webpackJsonp||[],d=i.push.bind(i);i.push=a,i=i.slice();for(var f=0;f<i.length;f++)a(i[f]);var b=d;r()}([]);
//# sourceMappingURL=manifest.4e257334f2c6d5876569.js.map
    (window.webpackJsonp=window.webpackJsonp||[]).push([[68],{302:function(e,t,r){"use strict";function n(e,t){for(var r=0;r<t.length;r++){var n=t[r];n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(e,n.key,n)}}function a(e,t,r){return t in e?Object.defineProperty(e,t,{value:r,enumerable:!0,configurable:!0,writable:!0}):e[t]=r,e}r.r(t),r.d(t,"PerfKeys",function(){return o});var o={NAVIGATION:"startup:navigation",NAVIGATION_TLS:"startup:navigation-tls",NAVIGATION_TTFB:"startup:navigation-ttfb",HTML:"startup:html",TIME_TO_INTERACTIVE:"startup:time-to-interactive",LOAD_TO_INTERACTIVE:"startup:page-load-to-interactive",APP:"startup:app.js",APP_DOWNLOAD:"download:app.js",LTP:"startup:ltp.js",LTP_DOWNLOAD:"download:ltp.js",FIRST_RENDER:"startup:first-render",QL_MEMBER_HEADER:"quickload:memberHeader",QL_MEMBER_BOARDS:"quickload:memberBoards",QL_MEMBER_QUICK_BOARDS:"quickload:memberQuickBoards",QL_SEARCH:"quickload:quickBoardSearch",QL_BOARD_MIN:"quickload:currentBoardMinimal",QL_BOARD_SECONDARY:"quickload:currentBoardSecondary",QL_BOARD_PLUGINS:"quickload:currentBoardPluginData",QL_CARD:"quickload:card",QL_ORGS:"quickload:organizationBoardsPage",BOOTSTRAP_HOME_VIEW:"bootstrap:member-home-view",BOOTSTRAP_SUPERHOME_VIEW:"bootstrap:member-super-home-view",BOOTSTRAP_CARD_VIEW:"bootstrap:card-view",BOOTSTRAP_BOARD_VIEW:"bootstrap:boards-view",BOOTSTRAP_IN_APP_GALLERY_VIEW:"bootstrap:in-app-gallery-view"},i="performance"in window,c=function(e){},s=Object.keys(o).map(function(e){return o[e]}),u="requestIdleCallback"in window?window.requestIdleCallback:setTimeout,p=function(){function e(){var t=this;!function(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}(this,e),a(this,"startupReported",!1),a(this,"Keys",o),a(this,"startMeasurement",i?function(e){if(-1!==s.indexOf(e))try{window.performance.mark("".concat(e,"-start"))}catch(e){console.error(e)}}:c),a(this,"stopMeasurement",i?function(e){if(-1!==s.indexOf(e))try{window.performance.mark("".concat(e,"-end")),window.performance.measure(e,"".concat(e,"-start"),"".concat(e,"-end"));var r=window.performance.getEntriesByName(e)[0];t.reportMetrics([{name:e,totalTime:r.duration}])}catch(e){console.error(e)}}:c)}var t,r,p;return t=e,(r=[{key:"reportMetrics",value:function(e){u(function(){e.forEach(function(e){e.name,e.totalTime})})}},{key:"reportStartupMetrics",value:function(){if(!this.startupReported){try{performance.mark("done"),window.performance.measure(o.LOAD_TO_INTERACTIVE,"startup:html-start","done");var e=window.performance.getEntriesByType("navigation")[0],t=window.performance.getEntriesByType("resource").filter(function(e){return"script"===e.initiatorType&&e.name.includes("ltp")})[0],r=window.performance.getEntriesByType("resource").filter(function(e){return"script"===e.initiatorType&&e.name.includes("app")})[0],n=window.performance.getEntriesByName(o.LOAD_TO_INTERACTIVE)[0],a=window.performance.getEntriesByName("done")[0];this.reportMetrics([{name:o.NAVIGATION,totalTime:e.responseEnd-e.fetchStart},{name:o.NAVIGATION_TLS,totalTime:e.secureConnectionStart>0?e.connectEnd-e.secureConnectionStart:0},{name:o.NAVIGATION_TTFB,totalTime:e.responseStart-e.requestStart},{name:o.TIME_TO_INTERACTIVE,totalTime:n.duration},{name:o.LOAD_TO_INTERACTIVE,totalTime:a.startTime-e.startTime},{name:o.LTP_DOWNLOAD,totalTime:t.responseEnd-t.responseStart},{name:o.APP_DOWNLOAD,totalTime:r.responseEnd-r.responseStart}])}catch(e){console.error(e)}this.startupReported=!0}}}])&&n(t.prototype,r),p&&n(t,p),e}();window.TrelloPerf=window.TrelloPerf?window.TrelloPerf:new p,t.default=window.TrelloPerf}},[[302,0]]]);
//# sourceMappingURL=perf.39a0b0c8bfaf5afbaa5c.js.map
    TrelloPerf.startMeasurement(TrelloPerf.Keys.HTML);
    TrelloPerf.startMeasurement(TrelloPerf.Keys.FIRST_RENDER);
  </script>
  <!-- GDPR Banner Configuration preventTrelloCookieConsent prevents banner from opening on page load-->
  <script>window.preventTrelloCookieConsent = true</script>
  <script src="https://a.trellocdn.com/prgb/dist/cookieConsent.cd58593665e31d54b161.js" crossorigin="anonymous" onerror="_failed(this)"></script>
  <!-- Google Analytics, load failure tracking, and data load kickoff -->
  <script>
    if ((document.cookie.indexOf("gdpr-cookie-consent=accepted") !== -1) || (document.cookie.indexOf("gdpr-user=true") === -1)) {
      (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)})(window,document,'script','//www.google-analytics.com/analytics.js','ga');
      var page = location.pathname;
      if(page === "/") page = "/boards";
      ga('create', 'UA-53826304-2', {
        cookieDomain: 'trello.com',
        sampleRate: 1
      });
      var versionParts = ''.split('-');
      ga('set', 'dimension1', versionParts.slice(0, -1).join('-'));
      ga('set', 'dimension2', versionParts.slice(-1)[0]);
      ga('send', 'pageview', page);
    }
    
    (function(i,c,e){if(!i[e]){i.GlobalSnowplowNamespace=i.GlobalSnowplowNamespace||[];
    i.GlobalSnowplowNamespace.push(e);i[e]=function(){(i[e].q=i[e].q||[]).push(arguments)
    };i[e].q=i[e].q||[];}}(window,document,"sp"));
  </script>
  <script src="https://a.trellocdn.com/prgb/dist/snowplow.4c4e526f617e48a0dfbc.js" async crossorigin="anonymous" onerror="_failed(this)"></script>
  
  <script type="text/javascript">
    if ((document.cookie.indexOf("gdpr-cookie-consent=accepted") !== -1) || (document.cookie.indexOf("gdpr-user=true") === -1)) {
      window.dataLayer=window.dataLayer||[];
      (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
      new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
      j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
      'https://www.googletagmanager.com/gtm.js?id='+i+dl+ '&gtm_auth=chlg06CfblVj204fihGEqA&gtm_preview=env-8&gtm_cookies_win=x';f.parentNode.insertBefore(j,f);
      })(window,document,'script','dataLayer','GTM-PJ8M5SK');
    }
  </script>
  
  <script src="https://a.trellocdn.com/prgb/dist/quickload.5840fb9977ec271695a0.js" crossorigin="anonymous" onerror="_failed(this)"></script>
  <script>QuickLoad.init()</script>
  <script>(function(b,c){var a=b.createElement("link");a.href=c;a.rel="stylesheet";a.type="text/css";b.getElementsByTagName("head")[0].appendChild(a)})(document,"https://a.trellocdn.com/prgb/dist/images.639d208c51b9c14e6391.css");</script>

  <link rel="mask-icon" href="https://a.trellocdn.com/prgb/dist/images/pinned-tab-icon.225c8d1cf8bbf74add43.svg" color="#0079BF">

  <!-- For third-generation iPad with high-resolution Retina display and iOS7: -->
  <link rel="apple-touch-icon-precomposed" sizes="152x152" href="https://a.trellocdn.com/prgb/dist/images/ios/apple-touch-icon-152x152-precomposed.0307bc39ec6c9ff499c8.png">
  <link rel="apple-touch-icon-precomposed" sizes="144x144" href="https://a.trellocdn.com/prgb/dist/images/ios/apple-touch-icon-144x144-precomposed.0dbf6daf256eb7678e5e.png">
  <!-- For iPhone with high-resolution Retina display and iOS7: -->
  <link rel="apple-touch-icon-precomposed" sizes="120x120" href="https://a.trellocdn.com/prgb/dist/images/ios/apple-touch-icon-120x120-precomposed.a68051b5c9144abe859b.png">
  <link rel="apple-touch-icon-precomposed" sizes="114x114" href="https://a.trellocdn.com/prgb/dist/images/ios/apple-touch-icon-114x114-precomposed.7f4a80b64fd8fd99840b.png">
  <!-- For first- and second-generation iPad: -->
  <link rel="apple-touch-icon-precomposed" sizes="72x72" href="https://a.trellocdn.com/prgb/dist/images/ios/apple-touch-icon-72x72-precomposed.91a3a04ec68a60903801.png">
  <!-- For non-Retina iPhone, iPod Touch, and Android 2.1+ devices: -->
  <link rel="apple-touch-icon-precomposed" href="https://a.trellocdn.com/prgb/dist/images/ios/apple-touch-icon-precomposed.8de2074e8a785dd5d498.png">

  <!-- To enable tab-to-search in Chrome -->
  <link type="application/opensearchdescription+xml" rel="search" href="/osd.xml"/>
</head>
<body>
  <div id="trello-root">
    <div id="nocss">
      Your browser was unable to load all of Trello's resources. They may
      have been blocked by your firewall, proxy or browser configuration.<br />
      Press Ctrl+F5 or Ctrl+Shift+R to have your browser try again and if
      that doesn't work, check out our
      <a href="http://help.trello.com/article/771-loading-resources-from-trellos-cdn">
        troubleshooting guide
      </a>.
      <hr />
    </div>
    <noscript className="big-message">
      <h1>To use Trello, please enable JavaScript.</h1>
    </noscript>
    <div id="chrome-container"></div>
    <!-- This div acts as a portal for react-beautiful-dnd -->
    <div id="dnd-portal"></div>
  </div>

  
  <script>TrelloPerf.startMeasurement(TrelloPerf.Keys.LTP);</script>
  <script src="https://a.trellocdn.com/prgb/dist/ltp.c3c51a78339bf4aefd40.js" crossorigin="anonymous" onerror="_failed(this)"></script>
  <script>TrelloPerf.stopMeasurement(TrelloPerf.Keys.LTP);</script>
  
  <script src="https://a.trellocdn.com/prgb/dist/locale.en-US.add3c0a70620294d7615.js" crossorigin="anonymous" onerror="_failed(this)"></script>
  <script>TrelloPerf.startMeasurement(TrelloPerf.Keys.APP);</script>
  <script src="https://a.trellocdn.com/prgb/dist/app.9034d8453a71d7c4668a.js" crossorigin="anonymous" onerror="_failed(this)" onload="TrelloPerf.stopMeasurement(TrelloPerf.Keys.APP);"></script>
  <script>TrelloPerf.stopMeasurement(TrelloPerf.Keys.HTML);</script>
</body>
</html>
