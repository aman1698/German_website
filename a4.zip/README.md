# German_website

Steps:

1. npm install express body-parser ejs nodemailer nodemailer-smtp-transport --save
2. node app.js
